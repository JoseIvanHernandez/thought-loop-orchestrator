$folders = @("Discovery", "Decision", "Action", "Serve", "Sustain")
foreach ($folder in $folders) {
    $path = ".\$folder"
    if (-not (Test-Path $path)) {
        New-Item -ItemType Directory -Path $path
        Write-Host "📁 Created folder: $folder"
    } else {
        Write-Host "⚠️ Folder already exists: $folder"
    }
}