$folders = @("Discovery", "Decision", "Action", "Serve", "Sustain")
foreach ($folder in $folders) {
    $tagPath = ".\$folder\_thought_tag.txt"
    if (-not (Test-Path $tagPath)) {
        "Tag: $folder stage" | Out-File -FilePath $tagPath -Encoding UTF8
        Write-Host "📝 Thought tag added to $folder"
    } else {
        Write-Host "🔁 Thought tag already exists in $folder"
    }
}