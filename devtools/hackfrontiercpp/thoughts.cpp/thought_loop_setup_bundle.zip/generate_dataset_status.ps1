$dataPath = "..\data\dsa_dataset_status.txt"
if (-Not (Test-Path $dataPath)) {
    "dataset1.html:Ready`ndataset2.html:Missing" | Out-File -FilePath $dataPath -Encoding UTF8
    Write-Host "✅ Created placeholder dataset status file."
} else {
    Write-Host "📂 Dataset status file already exists."
}